Skeleton project for Apigee-127
